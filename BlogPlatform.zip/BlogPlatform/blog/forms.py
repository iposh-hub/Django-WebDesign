from django.forms import ModelForm
from .models import Comment
class CommentForm(ModelForm):
    class Meta:
        model=Comment
        fields=('user_name','user_email', 'text')