from django.db import models
from django.db.models.base import ModelBase
from django.urls import reverse 

# Create your models here.

class Author(models.Model):
    full_Name= models.CharField(max_length= 150)
    e_mail= models.EmailField(max_length=50)
    aboutAuthor= models.TextField()
    authorImage= models.ImageField(upload_to="author_image", null=True )
    def __str__(self):
        return self.full_Name

class Tag(models.Model):
    caption = models.CharField(max_length=30)
    def __str__(self):
        return self.caption

class Post (models.Model):
    title= models.CharField (max_length=100)
    excerpt= models.CharField(max_length=300)
    author=models.ForeignKey(Author, on_delete= models.SET_NULL, null=True, related_name="posts" )
    image= models.ImageField(upload_to="postImages", null=True)
    date=models.DateField(auto_now=True)
    slug= models.SlugField(default="", blank=True, null=False, unique=True )
    content= models.TextField()
    tags=models.ManyToManyField(Tag, related_name="posts")
    def get_absolute_url(self):
        return reverse("single-post", args=[self.slug])
    
    def __str__(self):  # how the instances of class should be output in the console, in the terminal 
        return f"{self.title} ({self.author})"

class Comment(models.Model):
    user_name=models.CharField(max_length=120)
    user_email=models.EmailField()
    text= models.TextField(max_length=400)
    post= models.ForeignKey(Post, on_delete=models.CASCADE, related_name= "comments")

