from django.urls import path
from . import views

urlpatterns = [
    path('', views.startingPage, name="index"),
    path("<slug:slug>", views.singleArticle, name="single-post")
]
