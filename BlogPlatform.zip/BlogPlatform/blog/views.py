from django.shortcuts import render
from django.shortcuts import get_object_or_404, render,redirect
from django.urls import reverse
from .models import Post
from .forms import CommentForm
from django.http import HttpResponseRedirect
# Create your views here.

def startingPage(request):
    all_posts= Post.objects.all().order_by("-id")
    latest_posts= Post.objects.all().order_by("-id")[:4]
    return render(request,"blog/index.html", {
        "latestPosts":latest_posts,
        "allPosts": all_posts,
    })


def singleArticle(request,slug):
    searched_post=get_object_or_404(Post, slug=slug)
    form= CommentForm
    if request.method=='POST':
        commentForm=CommentForm(request.POST)
        if commentForm.is_valid():
            comment= commentForm.save(commit=False)
            comment.post=searched_post
            comment.save()
            #messages.success(request,'Form has been submitted')
            return HttpResponseRedirect(reverse("single-post", args=[slug]))
        context={
            'comments': searched_post.comments.all().order_by("-id"),
            'tags': searched_post.tags.all(),
            'form':form,
            'post':searched_post, }
        return render(request, 'blog/single-post.html',context)

    return render(request,'blog/single-post.html', {
        'form': form,
        'post':searched_post,
        'comments': searched_post.comments.all().order_by("-id"),
        'tags': searched_post.tags.all(),
        })

    return render (request,"blog/single-post.html", {
        "post": searched_post,
        "tags": searched_post.tags.all(),
    })